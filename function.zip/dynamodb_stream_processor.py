import boto3
import json
import logging

def lambda_handler(event, context):
    """AWS Lambda function to process DynamoDB Stream events."""
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

    try:
        # Process each record in the event
        for record in event['Records']:
            if record['eventName'] in ['INSERT', 'MODIFY']:
                # Extract the new image from the DynamoDB Stream record
                new_image = record['dynamodb']['NewImage']
                thread_id = new_image.get('thread_id', {}).get('S', 'unknown')
                chat_log = new_image.get('chat_log', {}).get('L', [])

                # Log the processed record
                logging.info(f"Processed record for thread_id: {thread_id}")
                logging.info(f"Chat log: {json.dumps(chat_log)}")

                # Add custom logic here to push updates to WebSocket server or other services

    except Exception as e:
        logging.error(f"Error processing DynamoDB Stream event: {str(e)}")
        raise e